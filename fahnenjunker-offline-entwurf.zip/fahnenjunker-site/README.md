# Fahnenjunker Webseite — Offline vorbereitet

Diese Webseite ist statisch aufgebaut: HTML, CSS, JavaScript, JSON und ICS-Kalenderdatei. Sie benötigt keine Datenbank, kein WordPress und keine laufenden Serverkosten.

## Lokal ansehen

Am einfachsten:

```bash
python -m http.server 8080
```

Dann im Browser öffnen:

```text
http://localhost:8080
```

Hinweis: Per Doppelklick funktionieren manche Browser-Funktionen wegen lokaler Sicherheitsregeln nicht zuverlässig. Der lokale Python-Server ist besser.

## Bilder ändern

1. Bilddateien in `assets/images/gallery/` legen.
2. `data/gallery.json` bearbeiten.
3. Pro Bild einen Eintrag anlegen:

```json
{"image":"assets/images/gallery/mein-bild.jpg","title":"Titel","text":"Beschreibung"}
```

## Termine ändern

1. `data/events.json` bearbeiten.
2. Optional `admin.html` lokal öffnen und Termine dort bearbeiten.
3. Danach `downloads/fahnenjunker-termine.ics` aktualisieren.

## GitHub Pages veröffentlichen

1. GitHub-Konto erstellen.
2. Neues Repository erstellen, z. B. `fahnenjunker`.
3. Diese Dateien hochladen.
4. In GitHub: Settings → Pages.
5. Source: Deploy from branch.
6. Branch: main, Folder: `/root`.
7. Speichern.

Danach ist die Seite unter `https://DEINNAME.github.io/fahnenjunker/` erreichbar.

## Wichtig vor Veröffentlichung

- Impressum vollständig mit echten Daten ausfüllen.
- Datenschutzerklärung auf den finalen Hostinganbieter anpassen.
- Nur eigene oder lizensierte Bilder verwenden.
- Keine externen Fonts, kein Tracking, keine eingebetteten fremden Dienste ohne Prüfung ergänzen.
